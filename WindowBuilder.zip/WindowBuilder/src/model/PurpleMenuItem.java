package model;

import java.awt.Color;

public class PurpleMenuItem extends MenuItem{
	
	public PurpleMenuItem() {
		this.setOpaque(true);
		this.setBackground(new java.awt.Color(193, 123, 185));
		this.setForeground(Color.WHITE);
	}
}
