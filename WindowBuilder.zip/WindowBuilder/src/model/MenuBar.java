package model;

import java.awt.Graphics;

import javax.swing.JMenuBar;

public abstract class MenuBar extends JMenuBar{
	
	public abstract void addMenu(Menu m);
}
