package model;

import java.awt.Color;

public class PurpleMenu extends Menu{
	
	public PurpleMenu() {
		this.setBackground(new java.awt.Color(193, 123, 185));
		this.setForeground(Color.WHITE);
	}
}
