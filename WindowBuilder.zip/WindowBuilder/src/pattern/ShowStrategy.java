package pattern;

import javax.swing.JTextPane;

public interface ShowStrategy {
	
	void show(JTextPane tp);
	
}
