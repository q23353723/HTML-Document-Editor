package pattern;

import javax.swing.JFrame;

public interface WindowImp {
	JFrame drawFrame();
	String getSystemName();
	void setUIFont();
}
